<?php

$razina = 30719;
error_reporting($razina);
?>
