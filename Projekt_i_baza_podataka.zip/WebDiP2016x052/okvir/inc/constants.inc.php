
<?php

    // Database credentials

    define('DB_HOST', 'localhost');
    define('DB_USER', 'WebDiP2016x052');
    define('DB_PASS', 'admin_Rpdb');
    define('DB_NAME', 'WebDiP2016x052');


?>


