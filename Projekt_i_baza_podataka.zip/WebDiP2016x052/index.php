 
<?php
header("Location: neprijavljeni.php");
?>