<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 14:42:31
         compiled from "predlosci/_footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:630159226592150c81edcd2-23684914%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e8a46f1d88baec80a6fd600d58394eacf319d6e5' => 
    array (
      0 => 'predlosci/_footer.tpl',
      1 => 1496407349,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '630159226592150c81edcd2-23684914',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592150c81f0975_13519133',
  'variables' => 
  array (
    'sat' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592150c81f0975_13519133')) {function content_592150c81f0975_13519133($_smarty_tpl) {?>
        <footer ng-app="footer" ng-controller="cjelo">

            <div class = "footer_left">
                <figure  >
                    <a href="dokumentacija.php">
                        <img src="slike/dokumentacija.jpg" width = "150" height="150" alt="dokumentacija">

                    </a>
                    <figcaption>Dokumentacija</figcaption>
                </figure> 
            </div>

            <div style= "<?php if (isset('sat')&&$_smarty_tpl->tpl_vars['sat']->value) {?>visibility: block;<?php } else { ?>visibility: hidden;<?php }?>" class = "footer_left">
             
                   
                   <p style="width: 50%;margin-left:25%; min-width:200px  " class = " vrijeme_izrade" ><b>{{ clock  | date:'HH:mm:ss'}}</b> <br>
             <b>{{ clock  | date:'dd.MM.yyyy.'}}</b></p>



            </div>

            <div class = "footer_left">
                <figure >
                    <a  href="dokumentacija.php?show=about"><img   src="slike/About-me.jpg" width = "150" height="150" alt="O meni"></a> 
                    <figcaption>O meni</figcaption>
                </figure> 
            </div>

            <div style="width: 100%; text-align: center">
                <address> <strong> Kontakt: </strong><a href = "mailto:zorhrncic@foi.hr"> Zoran Hrnčić</a></address>
                <p>Izdario 31.05.2017</p>

                <p> <small>&copy;   31.05.2017 Z. Hrncic</small></p>
            </div>

        </footer>




    </body>
</html><?php }} ?>
