<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 00:43:42
         compiled from "predlosci/kosarica.tpl" */ ?>
<?php /*%%SmartyHeaderCode:185436818959243908372172-27114721%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '496faf05f273672940e62ffc4d1692763604d944' => 
    array (
      0 => 'predlosci/kosarica.tpl',
      1 => 1496352636,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '185436818959243908372172-27114721',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592439083b0885_27280519',
  'variables' => 
  array (
    'ispisKupljenih' => 0,
    'elem' => 0,
    'ispis' => 0,
    'brojBodova' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592439083b0885_27280519')) {function content_592439083b0885_27280519($_smarty_tpl) {?>


        <div ng-app="kosarica" ng-controller="cijelo" class="tijelo tijeloAdmin">

            <!-- modal diskusije-->
            <div ng-show="otvoriModal" style="display: block"id="myModalKod" class="modal">

                <!-- Modal content -->
                <div class="modal-content">
                    <span ng-click="zatvoriModalKod()" class="close">&times;</span>



                    <div class="naslov">
                        <h1 >{{kodKupona[0].Naziv}} </h1>

                    </div>




                    <ul>
                        <li class="karticaDiskusije">
                            <h3 class="nazivPodrucjaInteresa" > <strong> KOD: </strong> {{kodKupona[0].Kod}}</h3>
                            <h3 class="nazivPodrucjaInteresa" > <strong> Datum kupnje: </strong> {{kodKupona[0].Datum}}</h3>
                        </li>



                    </ul>

                    <div class="naslov" style="background: white">
                        <button ng-click="zatvoriModalKod()" id="btnZatvori"> Zatvori pregled</button> 

                    </div>
                        
                         <div class="naslov" style="background: white">
                        <button onclick="myFunctionispis()" id="btnZatvori"> Ispis</button> 


<script>
function myFunctionispis() {
    window.print();
}
</script>
                    </div>








                </div>

            </div>
         



            <div class="section">

                <div class="naslov">
                    <h1>Košarica</h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">




                        <div ng-show="kupljeniArtikli" class="galerijaKupon kosarica">

                        <a>  <button ng-click="PrikaziKosaricu()" class="btnNavL"> Artikli u košarici</button> </a>
                        <a>  <button ng-click="PrikaziKupljene()" class="btnNavD"> Kupljeni artiki</button> </a>


                            <h3>Kupljeni artikli</h3>

<?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisKupljenih']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                            <div class="kupon">
                                <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['Slika'];?>
"style="max-width: 100%;height: 200px;">
                                <p><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_kupona'];?>
<br><b>Plačeno: <?php echo $_smarty_tpl->tpl_vars['elem']->value['Iznos'];?>
</b></p>

                                <div class="ikonaKupi">
                                     <button class="gumbKupnjaKupona" onclick="window.location.href = 'kupon.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
&kupljen=true'"> Pregled </button>
                                    <button ng-click="otovoriModalKod($event)" data-id="<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupljlenoga'];?>
" class="gumbKupnjaKupona"> Prikaži kod</button>
                                    <!-- data_id je id_kupljenog-->
                                </div>


                            </div>
<?php } ?>


                  

                        </div>
                        <div ng-show="artikliKosarica"class="galerijaKupon kosarica">
    <a>  <button ng-click="PrikaziKosaricu()" class="btnNavL"> Artikli u košarici</button> </a>
                        <a>  <button ng-click="PrikaziKupljene()" class="btnNavD"> Kupljeni artiki</button> </a>


                            <h3>Artikli u  košarici</h3>
<!--
                            <div >
                                <button class="gumbKupi" style="width: 100%">Kupi sve u košarici </button>
                            </div>
                            
                            -->
<?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispis']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                            <div class="kupon">
                                <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['Slika'];?>
"style="max-width: 100%;height: 200px;">
                                <p><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_kupona'];?>
<br><b><?php echo $_smarty_tpl->tpl_vars['elem']->value['Min_broj_bodova'];?>
 bodova</b></p>

                                <div class="ikonaKupi">
                                    <button class="gumbKupnjaKupona" onclick="window.location.href = 'kupon.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
&kupljen=true'"> Pregled </button>
                                    <button style="" class="gumbKupnjaKupona" onclick="window.location.href = 'kosarica.php?obrisi=kosarica&ID=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_stavke'];?>
'"> Obrisi </button>
                                  
                                    
                                    <form  action="kosarica.php" method="post">  
                                       
                                        <input name = "IDstavke" value="<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_stavke'];?>
" style="display: none">
                                            
                                            
                                        
                                        <button style="width: 93%" class="gumbKupnjaKupona" type="submit" name="kupovina"> Kupi </button>
                                    
                                            </form>
                                
                                </div>


                            </div>
                            
                            
                            <?php } ?>
       
                        </div>


                    </div>
                    <div class="desnoOglasi">
                        <p >Ukupan broj bodova:</p>

                        <h1><?php echo $_smarty_tpl->tpl_vars['brojBodova']->value;?>
</h1>

                    </div>

                </div>

            </div>
  
        </div><?php }} ?>
