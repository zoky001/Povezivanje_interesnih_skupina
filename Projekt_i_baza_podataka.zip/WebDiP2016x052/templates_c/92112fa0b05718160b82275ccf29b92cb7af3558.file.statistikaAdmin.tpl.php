<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 17:10:11
         compiled from "predlosci/statistikaAdmin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:798118719592d5a7e70d956-44993221%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '92112fa0b05718160b82275ccf29b92cb7af3558' => 
    array (
      0 => 'predlosci/statistikaAdmin.tpl',
      1 => 1496416208,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '798118719592d5a7e70d956-44993221',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592d5a7e80e076_83029104',
  'variables' => 
  array (
    'korisnik' => 0,
    'ispisSvihAktivnosti' => 0,
    'elem' => 0,
    'tipZapisa' => 0,
    'bpa' => 0,
    'bpk' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592d5a7e80e076_83029104')) {function content_592d5a7e80e076_83029104($_smarty_tpl) {?>

        <div ng-app="statistika" ng-controller="ctrlRead" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Pregled statistika </h1>

                </div>


                <div style="width: 100%;">
                    <div   class="glavniDio" style="width: 98%" >

                        <nav style="width:20%;">

                            <h4> STATISTIKA: </h4>
                          
                            <ul>
                             
                                    <li> <a href="statistikaAdmin.php?show=BpoK">Bodovi po korisniku</a></li>
                                    <li> <a href="statistikaAdmin.php?show=BpoA">Bodovi po aktivnosti</a></li>
                             
                            </ul>


                        </nav>

                        <div class="galerija">
                         


 <?php if (isset($_smarty_tpl->tpl_vars['korisnik']->value)&&$_smarty_tpl->tpl_vars['korisnik']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3> Pregled po korisniku </h3> 
                            </div>

         <div style="margin-left: 33%"> 

    <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Ime korisnika:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                    <?php if (isset($_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value)&&$_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value) {?>
                                  <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>

 

  <option  value="<?php echo $_smarty_tpl->tpl_vars['elem']->value['korisnik_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['ime'];?>
 <?php echo $_smarty_tpl->tpl_vars['elem']->value['prezime'];?>
 </option>
  
                                  
                                  <?php } ?>     
  <?php }?>
</select>

<br>



                                <input ng-click="prikaziKorisniku()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
    
    
    
    <?php if (isset($_smarty_tpl->tpl_vars['tipZapisa']->value)&&$_smarty_tpl->tpl_vars['tipZapisa']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Pregled po tipu zapisa</h3> 
                            </div>

         <div style="margin-left: 33%"> 

    <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Tip aktivnosti:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                    <?php if (isset($_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value)&&$_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value) {?>
                                  <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>

 

  <option  value="<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_aktivnosti'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_aktivnosti'];?>
</option>
  
                                  
                                  <?php } ?>     
  <?php }?>
</select>
<br>




                                <input ng-click="prikaziAktivnosti()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
    
                    
    
<?php if (isset($_smarty_tpl->tpl_vars['bpa']->value)&&$_smarty_tpl->tpl_vars['bpa']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Statistika skupljenih i potrošenih bodova prema aktivnosti</h3> 
                            </div>

         <div style="margin-left: 33%"> 

     <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Aktivnosti:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                 
  <option  value="Zarada">Zarada bodova</option>
  
  <option  value="Kupnja">Trošenje bodova</option> 
                                 
 
</select>
<br>




                                <input ng-click="prikazBpA()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
 
<div ng-show="prikaziStatistikaBPA">
    
    <button style="margin-left: -30%" class="gumb" name="provjeraKod" type="submit" ng-click="printDiv('i')" >Ispiši statistiku</button>
    <br>
     <form method="post" action="pdf/pdfStatistika.php" target="_blank">
            
         <input style="display:none" name="aktivnosti" value="1">
             
         
         <input style="display:none" name="statistika" value="{{pdfBPA}}">
          <button style="margin-left: -30%" class="gumb" name="provjeraKod" type="submit"  >Preuzmi PDF</button>
          </form>


<div id="i">
    <table  style = "margin-left: 0;width:100%" class="tablica1">
                                     <caption class="tablica1">Prikaz statistike bodova po aktivnosti</caption>
                <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  style="width:200px" custom-sort order="'id'" sort="sort">Aktivnost&nbsp;</th>
                        <th  custom-sort order="'name'" sort="sort">{{aktivnost}}&nbsp;</th>
                       
                    </tr>
                </thead>
                <tfoot class="tablica1">
                    <td colspan="6">
                        <div style="width:50%; margin-left:29%; margin-bottom: 5px;margin-top: 5px" >
                            <ul>
                                <li class="preNext" 
                                    
                                    ng-class="{ disabled: currentPage == 0 }" 
                                    
                                    >
                                    <a href ng-click="prevPage()">« Prethodna</a>
                                </li>
                            
                                <li class="preNext" ng-repeat="n in range(pagedItems.length, currentPage, currentPage + gap) "
                                   
                                    ng-class="{ active: n == currentPage }"
                                    
                                    
                                ng-click="setPage()">
                                    <a href ng-bind="n + 1">1</a>
                                </li>
                             
                                <li class="preNext"
                                    
                                    ng-class="{ disabled: (currentPage) == pagedItems.length - 1 }"
                                     >
                                  
                                    <a href ng-click="nextPage()">Sljedeća»</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tfoot>
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in pagedItems[currentPage] | orderBy:sort.sortingOrder:sort.reverse">
                     
                        <td>{{item.Aktivnost}}</td>
                         <td>{{item.Bodova}}</td>
                       
                        
                       
                       
                    </tr>
                </tbody>
            </table>
   
                         
                         
                         
<canvas style ="margin: 10px;" id="platno" width="1000" height="400">
</canvas>
                                        
   </div>                
                         
     <table  style = "margin-left: 0;width:100%" class="tablica1">
              <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  style="width:200px" >Legenda&nbsp;</th>
                      
                    </tr>
                </thead>
               
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in boje">
                     
                     <td style ="background-color:{{item.boja}}; color:black">   {{item.naziv}}</td>
                       
                        
                       
                       
                    </tr>
                </tbody>
            </table>                     

</div>
    
<?php if (isset($_smarty_tpl->tpl_vars['bpk']->value)&&$_smarty_tpl->tpl_vars['bpk']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Statistika skupljenih i potrošenih bodova korisnika</h3> 
                            </div>

         <div style="margin-left: 33%"> 

     <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Aktivnost:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                 

  <option  value="Zarada">Zarada bodova</option>
  
  <option  value="Kupnja">Trošenje bodova</option>                              
 
</select>
<br>




                                <input ng-click="prikazBpK()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
   

 
 
    
    
    
    <?php }?>
    
   
    
    <div ng-show="prikaziStatistikaBPK" >
        <br>
         <button style="margin-left: -30%" class="gumb" name="provjeraKod" type="submit" ng-click="printDiv('j')" >Ispiši statistiku</button>
    <br>
          <br>
          <form method="post" action="pdf/pdfStatistika.php" target="_blank">
              
              <input style="display:none" name="statistika" value="{{pdfBPK}}">
               <input style="display:none" name="aktivnosti" value="0">
          <button style="margin-left: -30%" class="gumb" name="provjeraKod" type="submit"  >Preuzmi PDF</button>
          </form>

       <div id="j">    
 <table  style = "margin-left: 0;width:100%" class="tablica1">
                                     <caption class="tablica1">Prikaz statistike bodova po korisniku</caption>
                <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  style="width:200px" custom-sort order="'id'" sort="sort">Korisnik&nbsp;</th>
                        <th  custom-sort order="'name'" sort="sort">{{aktivnost}}&nbsp;</th>
                       
                    </tr>
                </thead>
                <tfoot class="tablica1">
                    <td colspan="6">
                        <div style="width:50%; margin-left:29%; margin-bottom: 5px;margin-top: 5px" >
                            <ul>
                                <li class="preNext" 
                                    
                                    ng-class="{ disabled: currentPage == 0 }" 
                                    
                                    >
                                    <a href ng-click="prevPage()">« Prethodna</a>
                                </li>
                            
                                <li class="preNext" ng-repeat="n in range(pagedItems.length, currentPage, currentPage + gap) "
                                   
                                    ng-class="{ active: n == currentPage }"
                                    
                                    
                                ng-click="setPage()">
                                    <a href ng-bind="n + 1">1</a>
                                </li>
                             
                                <li class="preNext"
                                    
                                    ng-class="{ disabled: (currentPage) == pagedItems.length - 1 }"
                                     >
                                  
                                    <a href ng-click="nextPage()">Sljedeća»</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tfoot>
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in pagedItems[currentPage] | orderBy:sort.sortingOrder:sort.reverse">
                     
                        <td>{{item.Korisnik}}</td>
                         <td>{{item.Bodova}}</td>
                       
                        
                       
                       
                    </tr>
                </tbody>
            </table>
     </div>                    
 <canvas style ="margin: 10px;" id="platno1" width="2000" height="400">
</canvas>
                                        
                         
                         
     <table  style = "margin-left: 0;width:100%" class="tablica1">
              <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  style="width:200px" >Legenda&nbsp;</th>
                      
                    </tr>
                </thead>
               
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in boje">
                     
                     <td style ="background-color:{{item.boja}}; color:black">   {{item.naziv}}</td>
                       
                        
                       
                       
                    </tr>
                </tbody>
            </table>  
                         
    
                        </div>








              
                </div>


            </div>

        </div>
 </div>

        </div>
<?php }} ?>
