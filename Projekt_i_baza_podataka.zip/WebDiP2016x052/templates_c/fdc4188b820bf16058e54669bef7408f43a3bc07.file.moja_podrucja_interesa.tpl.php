<?php /* Smarty version Smarty-3.1.18, created on 2017-06-03 11:23:29
         compiled from "predlosci/moja_podrucja_interesa.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10450495325923636c01cbb8-26586115%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fdc4188b820bf16058e54669bef7408f43a3bc07' => 
    array (
      0 => 'predlosci/moja_podrucja_interesa.tpl',
      1 => 1496481695,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10450495325923636c01cbb8-26586115',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5923636c05aa85_79664345',
  'variables' => 
  array (
    'ispisPodrucja' => 0,
    'elem' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5923636c05aa85_79664345')) {function content_5923636c05aa85_79664345($_smarty_tpl) {?>
 <div class="tijelo">
        <section id="sadrzaj">


            <div class="naslov">
                <h1 >  Moja područja interesa </h1>

            </div>

            <div id =popisPodrucja class = "popisPodrucja">


            
                
                   <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisPodrucja']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>


                
                
                     <div class ="karticaPodrucja">
                    <h3 class="nazivPodrucjaInteresa" ><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv'];?>
</h3>

                    <figure >
                        <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['URLSlike'];?>
" alt="logo" class="slikaKarticePodrucja" >


                    </figure> 

                    <a href="popis_diskusija.php?IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja_interesa'];?>
"> <button class="btnNav"> Pregledaj diskusije</button>  </a>
                
                  

                </div>
                
                
                <?php } ?>
                
                
                
         
            </div>




        </section>
     </div>

  
<?php }} ?>
