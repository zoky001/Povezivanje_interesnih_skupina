<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 15:12:22
         compiled from "predlosci/otkljucavanjeAdmin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1401381503592da48eb24b35-62593909%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e2c7280872bf34de642356e506ba4a2070302671' => 
    array (
      0 => 'predlosci/otkljucavanjeAdmin.tpl',
      1 => 1496409139,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1401381503592da48eb24b35-62593909',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592da48ece1de4_89327045',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592da48ece1de4_89327045')) {function content_592da48ece1de4_89327045($_smarty_tpl) {?>

        <div ng-app="otkljucavanje" ng-controller="ctrlRead" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Pregled zaključanih korisnika </h1>

                </div>


                <div style="width: 100%;">
                    <div   class="glavniDio" style="width: 98%" >

                        <nav style="width:20%;">

                            <h4> PREGLED: </h4>
                          
                            <ul>
                             
                                    <li ng-click="dohvatiZakljucane()" > <a>ZAKLJUČANI</a></li>
                                    <li ng-click="dohvatiOtkljucane()"> <a>OTKLJUČANI</a></li>
                             
                            </ul>


                        </nav>

                        <div class="galerija">
                         



    
                            <div ng-show ="prikazKorisnikaOTK">

                                 <div class="naslov">
                                
 <h3> Upravljanje korisnicima </h3> 
                            </div>
     
      <table  style = "margin-left: 0;width:100%" class="tablica1">
                                     <caption class="tablica1">Prikaz korisnika</caption>
                <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                         <th  custom-sort order="'name'" sort="sort">Ime &nbsp;</th> 
                         <th  custom-sort order="'name'" sort="sort">Prezime &nbsp;</th>
                        <th  style="width:200px" custom-sort order="'id'" sort="sort">Aktivnost&nbsp;</th>
                       
                       
                    </tr>
                </thead>
                <tfoot class="tablica1">
                    <td colspan="6">
                        <div style="width:50%; margin-left:29%; margin-bottom: 5px;margin-top: 5px" >
                            <ul>
                                <li class="preNext" 
                                    
                                    ng-class="{ disabled: currentPage == 0 }" 
                                    
                                    >
                                    <a href ng-click="prevPage()">« Prethodna</a>
                                </li>
                            
                                <li class="preNext" ng-repeat="n in range(pagedItems.length, currentPage, currentPage + gap) "
                                   
                                    ng-class="{ active: n == currentPage }"
                                    
                                    
                                ng-click="setPage()">
                                    <a href ng-bind="n + 1">1</a>
                                </li>
                             
                                <li class="preNext"
                                    
                                    ng-class="{ disabled: (currentPage) == pagedItems.length - 1 }"
                                     >
                                  
                                    <a href ng-click="nextPage()">Sljedeća»</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tfoot>
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" style="background-color:{{boja}}"  ng-repeat="item in pagedItems[currentPage] | orderBy:sort.sortingOrder:sort.reverse">
                     
                        <td>{{item.Ime}}</td>
                         <td>{{item.Prezime}}</td>
                       <td><a href =otkljucavanjeKorisnika.php?{{gget}}={{item.Korisnik}}<?php ?>>{{akcija}}</a></td>
                        
                       
                       
                    </tr>
                </tbody>
            </table>
    
                                
                        </div>                        
 
    
    
    
 
    
                    
    

 


    
  
                        </div>


                    </div>





                   
                </div>


            </div>

        </div>
<?php }} ?>
