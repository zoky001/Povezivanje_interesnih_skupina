<?php /* Smarty version Smarty-3.1.18, created on 2017-06-01 11:24:23
         compiled from "predlosci/sakupljanjeBodova.tpl" */ ?>
<?php /*%%SmartyHeaderCode:131751551959242ebae12056-04812890%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5d334b0015a5996306dd1f605d6a15de13f7d4bc' => 
    array (
      0 => 'predlosci/sakupljanjeBodova.tpl',
      1 => 1496309061,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '131751551959242ebae12056-04812890',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_59242ebae56d12_76772449',
  'variables' => 
  array (
    'ID' => 0,
    'brojBodova' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59242ebae56d12_76772449')) {function content_59242ebae56d12_76772449($_smarty_tpl) {?>




        <div ng-app="pregledbodova" ng-controller="bodovi" class="tijelo">

            

           
            <div class="section">

                <div class="naslov">
                    <h1>Pregled sakupljenih bodova</h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">
                            <form style="text-align: left"  class="provjraKupona"  name="ProvjeraKoda"  
                                  >

         <div style="margin-left: 33%"> 


<br>

   <input ng-click="prikazSve(<?php echo $_smarty_tpl->tpl_vars['ID']->value;?>
,'sve')" style="margin-left: -25%"class="gumb" type="submit" value="Prikaži sve zapise"> <br>
 <input ng-click="prikazSve(<?php echo $_smarty_tpl->tpl_vars['ID']->value;?>
,'zarada')" style="margin-left: -25%"class="gumb" type="submit" value="Prikaži zarađene"> <br>
  <input ng-click="prikazSve(<?php echo $_smarty_tpl->tpl_vars['ID']->value;?>
,'kupnja')" style="margin-left: -25%"class="gumb" type="submit" value="Prikaži potrošene"> <br>

         </div>






                            </form>
  <br>
 <table ng-show="prikazTablice" style = "margin-left: 0;width:100%" class="tablica1">
                                     <caption class="tablica1">Tablica "korisnici"</caption>
                <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  custom-sort order="'id'" sort="sort">Akcija &nbsp;</th>
                        <th  custom-sort order="'id'" sort="sort">Vrijeme&nbsp;</th>
                        <th  custom-sort order="'name'" sort="sort">Aktivnost&nbsp;</th>
                       <th  custom-sort order="'name'" sort="sort">Opis aktivnosti&nbsp;</th>
                         <th  custom-sort order="'name'" sort="sort">Broj bodova&nbsp;</th>
                      
                     
                    
                       
                       
                    </tr>
                </thead>
                <tfoot class="tablica1">
                    <td colspan="6">
                        <div style="width:50%; margin-left:29%; margin-bottom: 5px;margin-top: 5px" >
                            <ul>
                                <li class="preNext" 
                                    
                                    ng-class="{ disabled: currentPage == 0 }" 
                                    
                                    >
                                    <a href ng-click="prevPage()">« Prethodna</a>
                                </li>
                            
                                <li class="preNext" ng-repeat="n in range(pagedItems.length, currentPage, currentPage + gap) "
                                   
                                    ng-class="{ active: n == currentPage }"
                                    
                                    
                                ng-click="setPage()">
                                    <a href ng-bind="n + 1">1</a>
                                </li>
                             
                                <li class="preNext"
                                    
                                    ng-class="{ disabled: (currentPage) == pagedItems.length - 1 }"
                                     >
                                  
                                    <a href ng-click="nextPage()">Sljedeća»</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tfoot>
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in pagedItems[currentPage] | orderBy:sort.sortingOrder:sort.reverse">
                      
                        <td>{{item.Akcija}}</td>
                         <td>{{item.Vrijeme}}</td>
                              <td>{{item.Aktivnost}}</td>
                              
                               <td>{{item.Opis}}</td>
                         <td>{{item.Broj}}</td>
                           
                    </tr>
                </tbody>
            </table>


                      

                    </div>

                    <div class="desnoOglasi">
                        <p >Ukupan broj bodova:</p>
                        
                        <h1><?php echo $_smarty_tpl->tpl_vars['brojBodova']->value;?>
</h1>

                    </div>
                </div>


            </div>

        </div>
  <?php }} ?>
