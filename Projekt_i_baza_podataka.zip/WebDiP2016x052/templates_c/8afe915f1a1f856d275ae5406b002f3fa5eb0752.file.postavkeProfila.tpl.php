<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 18:51:49
         compiled from "predlosci/postavkeProfila.tpl" */ ?>
<?php /*%%SmartyHeaderCode:909368982593191379237f3-49935918%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8afe915f1a1f856d275ae5406b002f3fa5eb0752' => 
    array (
      0 => 'predlosci/postavkeProfila.tpl',
      1 => 1496422307,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '909368982593191379237f3-49935918',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_593191379c0385_37906907',
  'variables' => 
  array (
    'Tema' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_593191379c0385_37906907')) {function content_593191379c0385_37906907($_smarty_tpl) {?>

        <div ng-app="diskusijeModerator" ng-controller="cijelo" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Uređenje postavki profila </h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio" style="width:99%;">

                      
                        <div class="galerija" style="width: 50%; margin-left: 25%">
                         
<?php if (isset($_smarty_tpl->tpl_vars['Tema']->value)&&$_smarty_tpl->tpl_vars['Tema']->value) {?>
    
                            <div style="text-align: left">
                                 <div class="naslov">
                                <h3 ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['ime'];?>
 <?php echo $_smarty_tpl->tpl_vars['Tema']->value['prezime'];?>
 </h3>

                            </div>
                                 
                               <form class="formaNovaDiskusija" method="post" name="Diskusija"  
                                  action="postavkeProfila.php" enctype="multipart/form-data">

                                 <div >
                                     <div style="text-align: center">
                    <figure >
                        <img style="max-width: 250px" src="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['slika'];?>
" alt="Slika profila" class="slikaKarticePodrucja" >


                    </figure> 
                                     </div>

                  
                </div>
                                <input  style="display: none"type="text" id="naziv"  name="IDkupona" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['korisnik_id'];?>
" > <br> 
                                
                                   <input  style="display: none"type="text" id="naziv"  name="Slika1" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['slika'];?>
" > <br> 
                                
                               

                                <label  id = "Lnaziv" for="naziv">Ime:      
                               </label>

                                <input   type="text" id="naziv"  name="ime"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['ime'];?>
" required > <br> 
                                
                                      <label  id = "Lnaziv" for="naziv">Prezime:      
                               </label>

                                <input   type="text" id="prezime"  name="prezime"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['prezime'];?>
" required > <br> 
                                
                                       <label  id = "Lnaziv" for="naziv">Korisničko ime:      
                               </label>

                                <input   type="text" id="naziv"  name="korime"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['korisnicko_ime'];?>
" required readonly> <br> 
                                
                                              <label  id = "Lnaziv" for="naziv">Email:      
                               </label>

                                <input   type="text" id="naziv"  name="email"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['email'];?>
" required readonly> <br> 
                                
                          <label  id = "Lnaziv" for="naziv">Prijava u dva koraka:      
                               </label>
                                
                                
                                <select name="dvaKoraka">
  <option value="0">NE</option>  
  <option <?php if ($_smarty_tpl->tpl_vars['Tema']->value['prijavaDvaKoraka']=='1') {?>selected<?php }?> value="1">DA</option>
 
</select>
                                
                                
 <label  >Dodaj sliku profila: </label>
  

 <input   style="height: 30px" type="file" name="fileToUpload" id="fileToUpload">
  


                                <input class= "gumb" type ="submit"  name="izmjenaPodataka" value="Izmjeni">
 
                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </div>
<?php }?>

                        </div>


                    </div>


                </div>


            </div>

        </div>
<?php }} ?>
