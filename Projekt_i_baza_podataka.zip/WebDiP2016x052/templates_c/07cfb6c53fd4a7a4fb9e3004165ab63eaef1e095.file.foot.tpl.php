<?php /* Smarty version Smarty-3.1.18, created on 2017-06-03 11:23:15
         compiled from "predlosci/foot.tpl" */ ?>
<?php /*%%SmartyHeaderCode:207126967159315fbd48dc49-20056272%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '07cfb6c53fd4a7a4fb9e3004165ab63eaef1e095' => 
    array (
      0 => 'predlosci/foot.tpl',
      1 => 1496481694,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '207126967159315fbd48dc49-20056272',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_59315fbd4caad8_73361963',
  'variables' => 
  array (
    'sat' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59315fbd4caad8_73361963')) {function content_59315fbd4caad8_73361963($_smarty_tpl) {?> 
 <footer ng-app="footer" ng-controller="cjelo">
 <div class = "footer_left">
                <figure  >
                    <a href="dokumentacija.php?show=era">
                        <img src="slike/dokumentacija.jpg" width = "150" height="150" alt="dokumentacija">

                    </a>
                    <figcaption>Dokumentacija</figcaption>
                </figure> 
            </div>
        <?php if (isset($_smarty_tpl->tpl_vars['sat']->value)&&$_smarty_tpl->tpl_vars['sat']->value) {?>
<div style= "visibility: block;" class = "footer_left">
             
                
                   <p style="width: 50%;margin-left:25%; min-width:200px  " class = " vrijeme_izrade" ><b>{{ clock  | date:'HH:mm:ss' }}</b> <br>
             <b>{{ clock  | date:'dd.MM.yyyy.' }}</b></p>
                
               
   </div>
 <?php } else { ?>
<div style= "visibility: hidden;" class = "footer_left">
             
                
                   <p style="width: 50%;margin-left:25%; min-width:200px  " class = " vrijeme_izrade" ><b>{{ clock  | date:'HH:mm:ss' }}</b> <br>
             <b>{{ clock  | date:'dd.MM.yyyy.' }}</b></p>
                
             
   </div>
         
        <?php }?>       
            <div class = "footer_left">
                <figure >
                    <a  href="dokumentacija.php?show=about"><img   src="slike/About-me.jpg" width = "150" height="150" alt="O meni"></a> 
                    <figcaption>O meni</figcaption>
                </figure> 
            </div>
             
              <div style="width: 100%; text-align: center">
                <address> <strong> Kontakt: </strong><a href = "mailto:zorhrncic@foi.hr"> Zoran Hrnčić</a></address>
                <p>Izdario 31.05.2017</p>

                <p> <small>&copy;   31.05.2017 Z. Hrncic</small></p>
           </div>
             
             </footer>
             
                 </body>
</html><?php }} ?>
