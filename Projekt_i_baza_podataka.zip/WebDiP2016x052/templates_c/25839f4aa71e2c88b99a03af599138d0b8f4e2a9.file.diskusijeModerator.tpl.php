<?php /* Smarty version Smarty-3.1.18, created on 2017-05-24 11:07:29
         compiled from "predlosci/diskusijeModerator.tpl" */ ?>
<?php /*%%SmartyHeaderCode:50234720859249d265de105-93560967%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '25839f4aa71e2c88b99a03af599138d0b8f4e2a9' => 
    array (
      0 => 'predlosci/diskusijeModerator.tpl',
      1 => 1495616843,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '50234720859249d265de105-93560967',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_59249d2661ba44_88994658',
  'variables' => 
  array (
    'podrucjeMOD' => 0,
    'ispisTema' => 0,
    'elem' => 0,
    'Tema' => 0,
    'IDpodrucjaMOD' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59249d2661ba44_88994658')) {function content_59249d2661ba44_88994658($_smarty_tpl) {?>

        <div ng-app="diskusijeModerator" ng-controller="cijelo" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Pregled diskusija - <?php echo $_smarty_tpl->tpl_vars['podrucjeMOD']->value;?>
</h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">

                        <nav style="width:20%;">

                            <h4>Diskusije:</h4>
                            <?php if (isset($_smarty_tpl->tpl_vars['ispisTema']->value)&&$_smarty_tpl->tpl_vars['ispisTema']->value) {?>
                            <ul>
                                <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisTema']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                                    <li> <a href="diskusijeModerator.php?IDdiskusije=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_diskusije'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv'];?>
</a></li>
                               <?php } ?>
                            </ul>

<?php }?>
                        </nav>

                        <div class="galerija">
                         
<?php if (isset($_smarty_tpl->tpl_vars['Tema']->value)&&$_smarty_tpl->tpl_vars['Tema']->value) {?>
    
                            <div style="text-align: left">
                                 <div class="naslov">
                                <h3 ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['Naziv'];?>
 </h3>

                            </div>
                               <form class="formaNovaDiskusija" method="post" name="Diskusija"  
                                  action="diskusijeModerator.php" novalidate>

                                
                                <input  style="display: none"type="text" id="naziv"  name="IDdiskusije" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['ID_diskusije'];?>
" > <br> 
                                
                                
                               

                                <label  id = "Lnaziv" for="naziv">Naziv diskusije:      
                               </label>

                                <input   type="text" id="naziv"  name="naziv"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Naziv'];?>
" required > <br> 
                                
                                

                                <label  id = "LdanPoc" for="danPoc">Početak diskusije:
                               </label>
                                <input  type="date" id="danPoc"  name="danPoc" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Datum_pocetka'];?>
" required >
                                
                                <br>
                                <label  id = "LdanKraja" for="danKraj">Kraj diskusije:
                               </label>
                                <input type="date" id="danKraj"  name="danKraj" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Datum_zavrsetka'];?>
" required=""><br>

                                <label   id = "Lopis" for="opis">Opis pravila:
                                   
                                </label>  
                                <label style="width: 95%" >(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['Opis_pravila'];?>
</textarea><br>








                                <input class= "gumb" type ="submit"  name="izmjenaDiskusije" value="Izmjeni diskusiju">
 
                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </div>
<?php }?>

                        </div>


                    </div>




                    <div class="desnoOglasi">
                        <button ng-click="otvoriModal()"id="btnNovaDiskusija"class="btnDiskusijaNova"> Dodaj novu diskusiju </button>

                    </div>

                    <!-- modal diskusije-->
                    <div ng-show="prikaziModal" id="myModalNovaDiskusija" style="display: block"class="modal">

                        <!-- Modal content -->
                        <div class="modal-content">
                            <span ng-click="zatvoriModal()" class="close">&times;</span>



                            <div class="naslov">
                                <h1 >Nova diskusija </h1>

                            </div>
   <div ng-show="Diskusija.naziv.$error.email2 || (Diskusija.danKraj.$invalid &&Diskusija.danKraj.$dirty )" class="greskeRegistracija" style=""> 

                 

                    <span ng-show="Diskusija.naziv.$error.email2" > Postojeći  naziv</span>

                    <span ng-show="Diskusija.danKraj.$invalid" > Datum kraja je maji od početnog </span>
                </div>

                            <form style="clear:both"class="formaNovaDiskusija" id="novi_proizvod" method="post" name="Diskusija"  
                                  action="diskusijeModerator.php" novalidate>

                                
                                <input  style="display: none"type="text" id="naziv"  name="IDPodrucja" value="<?php echo $_smarty_tpl->tpl_vars['IDpodrucjaMOD']->value;?>
" > <br> 
                                
                                
                                

                                <label  id = "Lnaziv" for="naziv">Naziv diskusije:      
                                    <img  id ="erNaziv" class = "greska_usklicnik"  src="slike/exclamation.jpg"  alt="exclamation">
                                </label>

                                <input  ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv" email2 required > <br> 
                                
                                   <span ng-show="Diskusija.naziv.$pending.email2">Provjera postojanja naziva...</span>

                                <label  id = "LdanPoc" for="danPoc">Početak diskusije:
                                    <img  id="erDanPro" class = "greska_usklicnik"  src="slike/exclamation.jpg"  alt="exclamation">
                                </label>
                                <input ng-model="pocDiskusije" type="date" id="danPoc"  name="danPoc"  min='{{ today | date :"y-MM-dd"  }}' placeholder ="gggg-mm-dd" required >
                                
                                <br>
                                <label  id = "LdanKraja" for="danKraj">Kraj diskusije:
                                    <img  id="erDanPro" class = "greska_usklicnik"  src="slike/exclamation.jpg"  alt="exclamation">
                                </label>
                                <input ng-model="krajDiskusije"type="date" id="danKraj"  placeholder ="gggg-mm-dd" name="danKraj" min='{{pocDiskusije}}'required=""><br>

                                <label  id = "Lopis" for="opis">Opis pravila:
                                    <img   id = "erOpis" class = "greska_usklicnik"  src="slike/exclamation.jpg"  alt="exclamation">
                                </label>  
                                <label style="width: 95%">(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea ng-model="opis" required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" placeholder="Ovdje unesite opis proizvoda"></textarea><br>








                                <input ng-disabled="Diskusija.naziv.$invalid || Diskusija.danPoc.$invalid || Diskusija.danKraj.$invalid || Diskusija.opis.$invalid" class="gumb" type="submit" name="novaDiskusija" value="Objavi diskusiju">

                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </ul>

                            <div class="naslov" style="background: white">
                                <button ng-click="zatvoriModal()" id="btnZatvori"> Zatvori pregled</button> 

                            </div>








                        </div>

                    </div>
                </div>


            </div>

        </div>
<?php }} ?>
