<?php /* Smarty version Smarty-3.1.18, created on 2017-05-30 21:53:36
         compiled from "predlosci/postavkeAdmin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:928964355592db973794364-60247249%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3ac03523a408262c5789abc3873dfe01685c8dc1' => 
    array (
      0 => 'predlosci/postavkeAdmin.tpl',
      1 => 1496174013,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '928964355592db973794364-60247249',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592db97389a030_32784010',
  'variables' => 
  array (
    'vrijeme' => 0,
    'vrijemeSustava' => 0,
    'datum' => 0,
    'stranicenje' => 0,
    'brojPrikaza' => 0,
    'bpa' => 0,
    'bpk' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592db97389a030_32784010')) {function content_592db97389a030_32784010($_smarty_tpl) {?>

        <div ng-app="log" ng-controller="ctrlRead" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Postavke </h1>

                </div>


                <div style="width: 100%;">
                    <div   class="glavniDio" style="width: 98%" >

                        <nav style="width:20%;">

                            <h4> AKCIJA: </h4>
                          
                            <ul>
                             
                                    <li> <a href="postavkeAdmin.php?show=vrijeme">Virtualno vrijeme</a></li>
                                    <li> <a href="postavkeAdmin.php?show=stranicenje">Straničenje</a></li>
                            </ul>


                        </nav>

                        <div class="galerija">
                         


 <?php if (isset($_smarty_tpl->tpl_vars['vrijeme']->value)&&$_smarty_tpl->tpl_vars['vrijeme']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3> Postavljanje vremena </h3> 
                            </div>
         <br>
         
                    <div class="naslov">
                                
                        <h3> <b>Trenutno vrijeme: </b> <?php echo $_smarty_tpl->tpl_vars['vrijemeSustava']->value;?>
</h3> 
                            </div>
                                                <div class="naslov">
                                
                        <h3> <b>Datum: </b> <?php echo $_smarty_tpl->tpl_vars['datum']->value;?>
</h3> 
                            </div>

         <div style="margin-left: 33%"> 
             <p><b>1. KORAK </b> - Odabrati "Postavi vrijeme" i upisati </p> <br>
 <p><b>2. KORAK </b> - Odabrati "Učitaj vrijeme" za pohranu</p> <br>
   

<br>



 <button style="margin-left: -25%"class="gumb"> <a  href="http://barka.foi.hr/WebDiP/pomak_vremena/vrijeme.html" target="_blank"> Postavi vrijeme </a></button> <br>
      <button style="margin-left: -25%"class="gumb"> <a  href="postavkeAdmin.php?postavi=vrijeme" > Učitaj vrijeme </a></button> <br>
 

         </div>






                            </form>
    
                                
                               
    <?php }?>
    
    
    
    <?php if (isset($_smarty_tpl->tpl_vars['stranicenje']->value)&&$_smarty_tpl->tpl_vars['stranicenje']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona"  name="ProvjeraKoda"  
                      action="postavkeAdmin.php"        method="post"    >


                                 <div class="naslov">
                                
 <h3 >Prikaz redaka po stranici</h3> 
                            </div>
         
                             <div class="naslov">
                                
                        <h3> <b>Trenutno: </b> <?php echo $_smarty_tpl->tpl_vars['brojPrikaza']->value;?>
 redaka</h3> 
                            </div>

         <div style="margin-left: 33%"> 

    <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Broj redaka po stranici:      
                              </label>

             <input  ng-model="broj redaka" type="number" min ="0" max="100" name="brojRedaka" value="<?php echo $_smarty_tpl->tpl_vars['brojPrikaza']->value;?>
"required="">
                                
                                
            
<br>




                                <input style="margin-left: -40%" class="gumb" name="pohranaRedaka" type="submit" value="Pohrani"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
    
                    
    
<?php if (isset($_smarty_tpl->tpl_vars['bpa']->value)&&$_smarty_tpl->tpl_vars['bpa']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Statistika skupljenih i potrošenih bodova prema aktivnosti</h3> 
                            </div>

         <div style="margin-left: 33%"> 

     <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Aktivnosti:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                 
  <option  value="Zarada">Zarada bodova</option>
  
  <option  value="Kupnja">Trošenje bodova</option> 
                                 
 
</select>
<br>




                                <input ng-click="prikazBpA()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
 

    
<?php if (isset($_smarty_tpl->tpl_vars['bpk']->value)&&$_smarty_tpl->tpl_vars['bpk']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Statistika skupljenih i potrošenih bodova korisnika</h3> 
                            </div>

         <div style="margin-left: 33%"> 

     <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Aktivnost:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                 

  <option  value="Zarada">Zarada bodova</option>
  
  <option  value="Kupnja">Trošenje bodova</option>                              
 
</select>
<br>




                                <input ng-click="prikazBpK()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
 
    
    
    
    <?php }?>
    
  
                        </div>


                    </div>





                </div>


            </div>

        </div>
<?php }} ?>
