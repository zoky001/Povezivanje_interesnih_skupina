<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 17:19:51
         compiled from "predlosci/kuponi_admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1730721914592c85250808b2-95085821%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '74ff6f08aa1401828554fabfcad38ff1b96945e2' => 
    array (
      0 => 'predlosci/kuponi_admin.tpl',
      1 => 1496416672,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1730721914592c85250808b2-95085821',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592c85251c2cd5_71046049',
  'variables' => 
  array (
    'ispisTema' => 0,
    'elem' => 0,
    'Tema' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c85251c2cd5_71046049')) {function content_592c85251c2cd5_71046049($_smarty_tpl) {?>

        <div ng-app="diskusijeModerator" ng-controller="cijelo" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Uređenje kupona članstva </h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">

                        <nav style="width:20%;">

                            <h4> Kuponi </h4>
                            <?php if (isset($_smarty_tpl->tpl_vars['ispisTema']->value)&&$_smarty_tpl->tpl_vars['ispisTema']->value) {?>
                            <ul>
                                <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisTema']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                                    <li> <a href="kuponiAdmin.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_kupona'];?>
</a></li>
                               <?php } ?>
                            </ul>

<?php }?>
                        </nav>

                        <div class="galerija">
                         
<?php if (isset($_smarty_tpl->tpl_vars['Tema']->value)&&$_smarty_tpl->tpl_vars['Tema']->value) {?>
    
                            <div style="text-align: left">
                                 <div class="naslov">
                                <h3 ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['Naziv_kupona'];?>
 </h3>

                            </div>
                                   <a href='kupon.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['Tema']->value['ID_kupona'];?>
'>  <button style="width: 90%;margin-left: -20%" class="gumb"> Pregled kupona </button></a>
                                
                               <form class="formaNovaDiskusija" method="post" name="Diskusija"  
                                  action="kuponiAdmin.php" enctype="multipart/form-data">

                                 <div >
                                     <div style="text-align: center">
                    <figure >
                        <img style="max-width: 250px" src="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Slika'];?>
" alt="Slika kupona" class="slikaKarticePodrucja" >


                    </figure> 
                                     </div>

                  
                </div>
                                <input  style="display: none"type="text" id="naziv"  name="IDkupona" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['ID_kupona'];?>
" > <br> 
                                
                                   <input  style="display: none"type="text" id="naziv"  name="Slika1" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Slika'];?>
" > <br> 
                                
                               

                                <label  id = "Lnaziv" for="naziv">Naziv kupona:      
                               </label>

                                <input   type="text" id="naziv"  name="naziv"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Naziv_kupona'];?>
" required > <br> 
                                
                                
                                <label   id = "Lopis" for="opis">Opis kupona:
                                   
                                </label>  
                                <label style="width: 95%" >(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['Opis_kupona'];?>
</textarea><br>
                         
                                  
                                
                              
                                  
                                  
                 
                                

 <label  >Dodaj sliku kupona: </label>
  

 <input   style="height: 30px" type="file" name="fileToUpload" id="fileToUpload">
  
  <label  style="visibility: hidden">Dodaj sliku kupona: </label>
  

 <input   style="height: 30px" type="file" name="fileToUpload1" id="fileToUpload">
   <label  style="visibility: hidden">Dodaj sliku kupona: </label>
  

 <input   style="height: 30px" type="file" name="fileToUpload2" id="fileToUpload">
  <label  style="visibility: hidden">Dodaj sliku kupona: </label>
  

 <input   style="height: 30px" type="file" name="fileToUpload3" id="fileToUpload">

    <label  id = "Lnaziv" for="naziv">URL video (samo YouTube):      
                               </label>

                                <input   type="url" id="video"  name="video"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Video'];?>
" required > <br> 
                                


                                <input class= "gumb" type ="submit"  name="izmjenaKupona" value="Izmjeni kupon">
 
                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </div>
<?php }?>

                        </div>


                    </div>




                    <div class="desnoOglasi">
                        <button ng-click="otvoriModal()"id="btnNovaDiskusija"class="btnDiskusijaNova"> Novi kupon</button>

                    </div>

                    <!-- modal diskusije-->
                    <div ng-show="prikaziModal" id="myModalNovaDiskusija" style="display: block"class="modal">

                        <!-- Modal content -->
                        <div class="modal-content">
                            <span ng-click="zatvoriModal()" class="close">&times;</span>



                            <div class="naslov">
                                <h1 >Novi kupon </h1>

                            </div>
   <div ng-show="Diskusija.naziv.$error.email2 || (Diskusija.danKraj.$invalid &&Diskusija.danKraj.$dirty )" class="greskeRegistracija" style=""> 

                 

                    <span ng-show="Diskusija.naziv.$error.email2" > Postojeći  naziv</span>

                    <span ng-show="Diskusija.danKraj.$invalid" > Datum kraja je maji od početnog </span>
                </div>

                            <form style="clear:both"class="formaNovaDiskusija" id="novi_proizvod" method="post" name="Diskusija"  
                                  action="kuponiAdmin.php" enctype="multipart/form-data"  >

                                
                               
                                
                                
                                

                                <label  id = "Lnaziv" for="naziv">Naziv kupona:      
                                  
                                </label>

                                <input   ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv"  required > <br> 
                                <!--
                                <input  ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv" email2 required > <br> 
                                
                                   <span ng-show="Diskusija.naziv.$pending.email2">Provjera postojanja naziva...</span>
-->
                                   
                                   
                           
                                <label  id = "Lopis" for="opis">Opis:
                               </label>  
                                <label style="width: 95%">(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea ng-model="opis" required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" placeholder="Ovdje unesite opis kupona"></textarea><br>



 

                               

                                <input ng-disabled="Diskusija.naziv.$invalid || Diskusija.danPoc.$invalid || Diskusija.danKraj.$invalid || Diskusija.opis.$invalid" class="gumb" type="submit" name="novoKupon" value="Pohrani kupon">

                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </ul>

                            <div class="naslov" style="background: white">
                                <button ng-click="zatvoriModal()" id="btnZatvori"> Zatvori pregled</button> 

                            </div>








                        </div>

                    </div>
                </div>


            </div>

        </div>
<?php }} ?>
