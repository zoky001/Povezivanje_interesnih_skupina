<?php /* Smarty version Smarty-3.1.18, created on 2017-06-03 11:23:31
         compiled from "predlosci/popisDiskusija.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1843779524592367cd2c3a41-55307346%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9be2a6570b738030fbd6ac0cf83e2790e4a636c3' => 
    array (
      0 => 'predlosci/popisDiskusija.tpl',
      1 => 1496481696,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1843779524592367cd2c3a41-55307346',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592367cd350907_14524195',
  'variables' => 
  array (
    'NazivPodrucja' => 0,
    'ispis' => 0,
    'elem' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592367cd350907_14524195')) {function content_592367cd350907_14524195($_smarty_tpl) {?>


        <div ng-app="popisDiskusija" ng-controller="cijelo" class="tijelo">

            <section id="sadrzaj" class="section1">

   <div class="naslov">
                    <h1 ><?php echo $_smarty_tpl->tpl_vars['NazivPodrucja']->value;?>
 </h1>

                </div>
             



                <ul>
                    
                    <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispis']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                    
                    
                    <li class="karticaDiskusije">
                        <a href="diskusija.php?IDdiskusije=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_diskusije'];?>
" > <h3 class="nazivPodrucjaInteresa" > <?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv'];?>
 </h3></a>
                    </li>
                    
                       <?php } ?>
                    
                    
                    
                   

                </ul>
                
                  <div class="naslov section1">
                       <button id="btnZatvori" ng-click="doTheBack()"> Povratak</button> 

                </div>


        </section>

 </div>

<?php }} ?>
