<?php /* Smarty version Smarty-3.1.18, created on 2016-01-19 11:07:16
         compiled from "predlosci\_footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4494569e0ad4d27162-30877958%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9985eac6fb86e4fc23e8a2de4522c9d117e6cf1d' => 
    array (
      0 => 'predlosci\\_footer.tpl',
      1 => 1453198001,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4494569e0ad4d27162-30877958',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_569e0ad4d28704_34778273',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_569e0ad4d28704_34778273')) {function content_569e0ad4d28704_34778273($_smarty_tpl) {?></section>
<footer>
    <address>
            Kontaktirajte me na:<br /> 
            <a href="mailto:matija.novak@foi.hr">Matija Novak</a>            
    </address>
    <p><small>© Sva prava pridržana, Web dizajn i programiranje, 2014.</small></p>
</footer>
</body>
</html><?php }} ?>
