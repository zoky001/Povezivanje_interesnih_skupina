<?php /* Smarty version Smarty-3.1.18, created on 2017-05-24 13:27:56
         compiled from "predlosci/pretplatnici.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15191670659255039a9eb33-94894536%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20859921ab566f8750b51587c6b5041d2b1967ad' => 
    array (
      0 => 'predlosci/pretplatnici.tpl',
      1 => 1495625213,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15191670659255039a9eb33-94894536',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_59255039ad8f30_54515760',
  'variables' => 
  array (
    'korisnici' => 0,
    'elem' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59255039ad8f30_54515760')) {function content_59255039ad8f30_54515760($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_replace')) include '/var/www/webdip.barka.foi.hr/2016_projekti/WebDiP2016x052/vanjske_biblioteke/Smarty/libs/plugins/modifier.replace.php';
?>

        <div ng-app="pretplatnici" ng-controller="cjelo"  class="tijelo  tijeloAdmin">


            <section id="sadrzaj" >


                <div class = "naslov">
                    <h3><i>Popis pretplatnika</i> </h3>
                </div>
                <div class="asocijativna">
                    
                    
                    
                    <button ng-click="otvoriModal()" id="btnNovaObavijest" class="gumb" style="margin-left: -50%"> Pošalji obavijest korisnicima</button> 
                    
              <form id="novi_proizvod" method="post" name="novi_proizvod"  
                    action="pretplatnici.php" novalidate>



                  <div  ng-show="prikaziModal" id="myModalNovaObavijest" style="display: block"class="modal">

                            <!-- Modal content -->
                            <div class="modal-content">
                                <span ng-click="zatvoriModal()"class="close">&times;</span>


                              
                                <div class="naslov">
                                    <h1 >Nova obavijest </h1>

                                </div>

                                <div class="formaNovaDiskusija" style="text-align: left"> 


                                <div id="refreshDiv" style="display:none">
                                    <input class= "gumbRef" id="refreshPage" type="button" value="Osvježi stranicu" >
                                </div>

                                    <label  id = "Lnaziv" for="naziv">Naslov:      
                                    <img  id ="erNaziv" class = "greska_usklicnik"  src="slike/exclamation.jpg"  alt="exclamation">
                                </label>

                                    <input required ng-model="naslov" type="text" id="naziv"  name="naziv" > <br> 



                                <label   id = "Ltekst" for="opis">Text poruke:
                                    <img   id = "erOpis" class = "greska_usklicnik"  src="slike/exclamation.jpg"  alt="exclamation">
                                </label>  
                                <textarea required ng-model="tekstPoruke"style="margin-left: -50%"class = "opis_area" id= "tekst" name="tekstPoruke" rows="5" cols="100" placeholder="Ovdje unesite tekst poruke"></textarea><br>








                                <input class="gumb" name="obavjest" type="submit" value="Pošalji obavijest korisnicima"> <br>

                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                                </div>





                                <div class="naslov" style="background: white">
                                    <button ng-click="zatvoriModal()" type="button" id="btnZatvori"> Zatvori pregled</button> 

                                </div>








                            </div>

                        </div>







                        <table class="tablica1" >
                            <caption class="tablica1">Pretplatnici</caption>

                            <thead class="tablica1">
                                <tr  class="tablica1_zaglavlje sh480">
                                    <th>Odabir</th>
                                    <th >Ime</th>
                                    <th>Prezime</th>
                                   
                                    <th> Status</th>
                                    <th> Aktivnost</th>


                                </tr>
                            </thead>

                            <tbody class="tablica1">

<?php if (isset($_smarty_tpl->tpl_vars['korisnici']->value)&&$_smarty_tpl->tpl_vars['korisnici']->value) {?>
<?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['korisnici']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                                <tr class="tablica1_redak1" <?php if ($_smarty_tpl->tpl_vars['elem']->value['Blokiran']=="1") {?>style="background-color: #FF806F; "  <?php }?>>

                                    <td>
                                        <input type="checkbox" name="Odabir[]" value = "<?php echo $_smarty_tpl->tpl_vars['elem']->value['email'];?>
">
                                    </td>
                                    <td>

                                        <?php echo $_smarty_tpl->tpl_vars['elem']->value['ime'];?>


                                    </td>

                                    <td >
                                       <?php echo $_smarty_tpl->tpl_vars['elem']->value['prezime'];?>

                                    </td>

                                    <td>
                                       <?php echo smarty_modifier_replace(smarty_modifier_replace($_smarty_tpl->tpl_vars['elem']->value['Blokiran'],"0","Aktivan"),"1","Blokiran");?>

                                    </td>

                                   
                                    <td>
                                        <?php if ($_smarty_tpl->tpl_vars['elem']->value['Blokiran']=="0") {?>
                                        <a href ="pretplatnici.php?IDkorisnika=<?php echo $_smarty_tpl->tpl_vars['elem']->value['korisnik_id'];?>
&aktivnost=blokiraj">Blokiraj</a>
                                    <?php } else { ?>
                                     <a href ="pretplatnici.php?IDkorisnika=<?php echo $_smarty_tpl->tpl_vars['elem']->value['korisnik_id'];?>
&aktivnost=odblokiraj">Odblokiraj</a>
                                    <?php }?>
                                    </td>


                                </tr>

           <?php } ?>                   

<?php }?>

                            </tbody>
                        </table>








                    </form>



                </div>










            </section>



<?php }} ?>
