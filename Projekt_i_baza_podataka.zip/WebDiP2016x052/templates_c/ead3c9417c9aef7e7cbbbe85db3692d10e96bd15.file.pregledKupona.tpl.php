<?php /* Smarty version Smarty-3.1.18, created on 2017-05-28 22:10:35
         compiled from "predlosci/pregledKupona.tpl" */ ?>
<?php /*%%SmartyHeaderCode:176415957959240ac79bb1b7-78939264%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ead3c9417c9aef7e7cbbbe85db3692d10e96bd15' => 
    array (
      0 => 'predlosci/pregledKupona.tpl',
      1 => 1496002226,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '176415957959240ac79bb1b7-78939264',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_59240ac79f33f5_60351543',
  'variables' => 
  array (
    'ispisPodrucja' => 0,
    'elem' => 0,
    'ispisKupona' => 0,
    'brojBodova' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59240ac79f33f5_60351543')) {function content_59240ac79f33f5_60351543($_smarty_tpl) {?>

        <div class="tijelo">


            <div class="section">

                <div class="naslov">
                    <h1>Popis kupona za kupnju</h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">

                        <nav style="width:20%;">

                            <h4>Popis kategorija:</h4>
                            
                            <ul>
                                <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisPodrucja']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                                    <li> <a href="pregled_kupona.php?IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja_interesa'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv'];?>
</a></li>
                                
                                <?php } ?>
                            </ul>


                        </nav>

                        <div class="galerija">
                             
                            
                            <?php if (isset($_smarty_tpl->tpl_vars['ispisKupona']->value)&&$_smarty_tpl->tpl_vars['ispisKupona']->value) {?>
                            <h3 style="text-align: left; margin-left: 20px;"><?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value[0]['Naziv'];?>
  </h3> 

                            <div style="text-align: left">
                                
                                
                                <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisKupona']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                                <div class="kupon">
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['Slika'];?>
"style="max-width: 100%;height: 200px;">
                                    <p><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_kupona'];?>
<br><b><strong>CIJENA: </strong><?php echo $_smarty_tpl->tpl_vars['elem']->value['Min_broj_bodova'];?>
</b></p>

                                    <div class="ikonaKupi">
                                        <button class="gumbKupnjaKupona" onclick="window.location.href='kupon.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
'"> Pregled </button>
                                        <a href="kosarica.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
"><button class="gumbKupnjaKupona">U košaricu</button></a>
                                       
                                    </div>
                                    
                                    
                                </div>
                                
                                <?php } ?>
                            
                            </div>

<?php }?>
                        </div>


                    </div>

                    <div class="desnoOglasi">
                        <p >Ukupan broj bodova:</p>

                        <h1><?php echo $_smarty_tpl->tpl_vars['brojBodova']->value;?>
</h1>

                    </div>
                </div>


            </div>

        </div>
<?php }} ?>
