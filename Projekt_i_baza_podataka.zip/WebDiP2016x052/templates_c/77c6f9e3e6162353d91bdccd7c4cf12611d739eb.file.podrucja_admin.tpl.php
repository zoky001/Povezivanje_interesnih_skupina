<?php /* Smarty version Smarty-3.1.18, created on 2017-05-29 22:22:04
         compiled from "predlosci/podrucja_admin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:678170308592b33683bd043-03447338%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '77c6f9e3e6162353d91bdccd7c4cf12611d739eb' => 
    array (
      0 => 'predlosci/podrucja_admin.tpl',
      1 => 1496089322,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '678170308592b33683bd043-03447338',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592b33684904f2_07095662',
  'variables' => 
  array (
    'ispisTema' => 0,
    'elem' => 0,
    'Tema' => 0,
    'IDmod' => 0,
    'ispisSvihKorisnika' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592b33684904f2_07095662')) {function content_592b33684904f2_07095662($_smarty_tpl) {?>

        <div ng-app="diskusijeModerator" ng-controller="cijelo" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Uređenje područja interesa </h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">

                        <nav style="width:20%;">

                            <h4>PODRUČJA INTERESA </h4>
                            <?php if (isset($_smarty_tpl->tpl_vars['ispisTema']->value)&&$_smarty_tpl->tpl_vars['ispisTema']->value) {?>
                            <ul>
                                <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisTema']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>
                                    <li> <a href="podrucjaAdmin.php?IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv'];?>
</a></li>
                               <?php } ?>
                            </ul>

<?php }?>
                        </nav>

                        <div class="galerija">
                         
<?php if (isset($_smarty_tpl->tpl_vars['Tema']->value)&&$_smarty_tpl->tpl_vars['Tema']->value) {?>
    
                            <div style="text-align: left">
                                 <div class="naslov">
                                <h3 ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['Naziv'];?>
 </h3>

                            </div>
                               <form class="formaNovaDiskusija" method="post" name="Diskusija"  
                                  action="podrucjaAdmin.php" enctype="multipart/form-data">

                                 <div >
                                     <div style="text-align: center">
                    <figure >
                        <img style="max-width: 250px" src="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['URLSlike'];?>
" alt="Slika područja" class="slikaKarticePodrucja" >


                    </figure> 
                                     </div>

                  
                </div>
                                <input  style="display: none"type="text" id="naziv"  name="ID_podrucja" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['ID_podrucja'];?>
" > <br> 
                                
                                   <input  style="display: none"type="text" id="naziv"  name="Slika1" value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['URLSlike'];?>
" > <br> 
                                
                               

                                <label  id = "Lnaziv" for="naziv">Naziv područja:      
                               </label>

                                <input   type="text" id="naziv"  name="naziv"  value="<?php echo $_smarty_tpl->tpl_vars['Tema']->value['Naziv'];?>
" required > <br> 
                                
                                
                                <label   id = "Lopis" for="opis">Opis područja:
                                   
                                </label>  
                                <label style="width: 95%" >(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" ><?php echo $_smarty_tpl->tpl_vars['Tema']->value['Opis_podrucja'];?>
</textarea><br>
                         
                                  <label   for="moderator">Moderator:    
                                  
                                </label>
                                
                                  <?php if (isset($_smarty_tpl->tpl_vars['IDmod']->value)&&$_smarty_tpl->tpl_vars['IDmod']->value['ID_moderatora']) {?>   
                                      
                           <input  style ="display:none" type="text" id="naziv"  name="IDstari"  value="<?php echo $_smarty_tpl->tpl_vars['IDmod']->value['ID_moderatora'];?>
" > <br> 
                                
                                      
                                  
                                  
                                  <?php }?> 
                                  
                                  
                                <select style = "height: 30px" name="IDmoderatora" required="">
                                    <?php if (isset($_smarty_tpl->tpl_vars['ispisSvihKorisnika']->value)&&'ispisSvihKorisnika') {?>
                                  <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisSvihKorisnika']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>

 

  <option  <?php if (isset($_smarty_tpl->tpl_vars['IDmod']->value)&&$_smarty_tpl->tpl_vars['IDmod']->value['ID_moderatora']==$_smarty_tpl->tpl_vars['elem']->value['korisnik_id']) {?>   selected <?php }?> value="<?php echo $_smarty_tpl->tpl_vars['elem']->value['korisnik_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['ime'];?>
 <?php echo $_smarty_tpl->tpl_vars['elem']->value['prezime'];?>
</option>
  
                                  
                                  <?php } ?>     
  <?php }?>
</select>
                                

 <label  >Dodaj sliku podrucja: </label>
  

 <input   style="height: 30px" type="file" name="fileToUpload" id="fileToUpload">
  




                                <input class= "gumb" type ="submit"  name="izmjenaPodrucja" value="Izmjeni diskusiju">
 
                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </div>
<?php }?>

                        </div>


                    </div>




                    <div class="desnoOglasi">
                        <button ng-click="otvoriModal()"id="btnNovaDiskusija"class="btnDiskusijaNova"> Novo područje interesa </button>

                    </div>

                    <!-- modal diskusije-->
                    <div ng-show="prikaziModal" id="myModalNovaDiskusija" style="display: block"class="modal">

                        <!-- Modal content -->
                        <div class="modal-content">
                            <span ng-click="zatvoriModal()" class="close">&times;</span>



                            <div class="naslov">
                                <h1 >Novo područje interesa </h1>

                            </div>
   <div ng-show="Diskusija.naziv.$error.email2 || (Diskusija.danKraj.$invalid &&Diskusija.danKraj.$dirty )" class="greskeRegistracija" style=""> 

                 

                    <span ng-show="Diskusija.naziv.$error.email2" > Postojeći  naziv</span>

                    <span ng-show="Diskusija.danKraj.$invalid" > Datum kraja je maji od početnog </span>
                </div>

                            <form style="clear:both"class="formaNovaDiskusija" id="novi_proizvod" method="post" name="Diskusija"  
                                  action="podrucjaAdmin.php" enctype="multipart/form-data"  >

                                
                               
                                
                                
                                

                                <label  id = "Lnaziv" for="naziv">Naziv područja interesa:      
                                  
                                </label>

                                <input   ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv"  required > <br> 
                                <!--
                                <input  ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv" email2 required > <br> 
                                
                                   <span ng-show="Diskusija.naziv.$pending.email2">Provjera postojanja naziva...</span>
-->
                                   
                                   
                           
                                <label  id = "Lopis" for="opis">Opis:
                               </label>  
                                <label style="width: 95%">(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea ng-model="opis" required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" placeholder="Ovdje unesite opis proizvoda"></textarea><br>



 

                               

                                <input ng-disabled="Diskusija.naziv.$invalid || Diskusija.danPoc.$invalid || Diskusija.danKraj.$invalid || Diskusija.opis.$invalid" class="gumb" type="submit" name="novoPodrucje" value="Objavi područje interesa">

                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </ul>

                            <div class="naslov" style="background: white">
                                <button ng-click="zatvoriModal()" id="btnZatvori"> Zatvori pregled</button> 

                            </div>








                        </div>

                    </div>
                </div>


            </div>

        </div>
<?php }} ?>
