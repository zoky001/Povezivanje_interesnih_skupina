<?php /* Smarty version Smarty-3.1.18, created on 2017-06-03 11:23:23
         compiled from "predlosci/podrucjaInteresa.tpl" */ ?>
<?php /*%%SmartyHeaderCode:98640680759235f2cdf2511-15864125%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a018f689dcc8f6892058227112f1a578ea5f22a' => 
    array (
      0 => 'predlosci/podrucjaInteresa.tpl',
      1 => 1496481696,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '98640680759235f2cdf2511-15864125',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_59235f2ce2c194_99582729',
  'variables' => 
  array (
    'coockieNeVrijediIF' => 0,
    'ispisPodrucja' => 0,
    'elem' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_59235f2ce2c194_99582729')) {function content_59235f2ce2c194_99582729($_smarty_tpl) {?>        <div   class="tijelo" >
            
            
            
                    <?php if (isset($_smarty_tpl->tpl_vars['coockieNeVrijediIF']->value)&&$_smarty_tpl->tpl_vars['coockieNeVrijediIF']->value) {?>
               <!-- modal registracija-->
        <div  style="display: block" id="myModal" class="modal">
        
        <!-- Modal content  coockie prihvat-->
            <div class="modal-content">
              


                <div class = "naslov">
                    <h3><i> Prihvačanje uvjeta korištenja </i> </h3>
                </div>



                <form   class="forma" id="uvjeti koristenja" method="post"  name="uvjeti"  
                        action="podrucja_interesa.php" >


                    <div>

                        <label style = "width: 90%; margin:5%;" for="ime">Za nastavak korištenja ovih stranica morate obavezno prihvatiti uvjete košištenja!!!!</label>
                    </div>
                   
  <input  style = "display: none" type="text" id="naziv"  name="coockieAccept" value = "1" ><br>






                    <input  class="gumb" type="submit" value="Prihvati uvjete korištenja">



                </form>






                

            </div>
    </div>
        
        <?php }?>
        
        
        
        
        <section id="sadrzaj">


            <div class="naslov">
                <h1 >   Popis područja interesa </h1>

            </div>

            <div id =popisPodrucja class = "popisPodrucja">

                   <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisPodrucja']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>


                
                
                     <div class ="karticaPodrucja">
                    <h3 class="nazivPodrucjaInteresa" ><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv'];?>
</h3>

                    <figure >
                        <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['URLSlike'];?>
" alt="logo" class="slikaKarticePodrucja" >


                    </figure> 

                    <a href="popis_diskusija.php?IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
"> <button class="btnNav"> Pregledaj diskusije</button>  </a>
                    <a href="moja_podrucja_interesa.php?IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
&add=true"><button class="btnNav"> Prati</button></a>
                  

                </div>
                
                
                <?php } ?>

   
            </div>




        </section>
 </div>
<?php }} ?>
