<?php /* Smarty version Smarty-3.1.18, created on 2017-06-03 10:31:23
         compiled from "predlosci/logAdmin.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2138171368592d031748ca27-55731473%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1a204e64ac4614c2c45fd1796274d360d7502c08' => 
    array (
      0 => 'predlosci/logAdmin.tpl',
      1 => 1496478676,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2138171368592d031748ca27-55731473',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592d0317513586_79615609',
  'variables' => 
  array (
    'Tema' => 0,
    'korisnik' => 0,
    'ispisSvihAktivnosti' => 0,
    'elem' => 0,
    'tipZapisa' => 0,
    'interval' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592d0317513586_79615609')) {function content_592d0317513586_79615609($_smarty_tpl) {?>

        <div ng-app="log" ng-controller="ctrlRead" class="tijelo"  >


            <div class="section">

                <div class="naslov">
                    <h1>Pregled dnevnika rada sustava </h1>

                </div>


                <div style="width: 100%;">
                    <div   class="glavniDio" style="width: 98%" >

                        <nav style="width:20%;">

                            <h4> PRETRAŽIVANJE: </h4>
                          
                            <ul>
                             
                                    <li> <a href="logAdmin.php?show=interval">Prema intervalu</a></li>
                                    <li> <a href="logAdmin.php?show=tipuZapisa">Prema aktivnosti</a></li>
                              <li> <a href="logAdmin.php?show=korisniku">Prema korisniku</a></li>
                            </ul>


                        </nav>

                        <div class="galerija">
                         
<?php if (isset($_smarty_tpl->tpl_vars['Tema']->value)&&$_smarty_tpl->tpl_vars['Tema']->value) {?>
    
                            <div style="text-align: left">
                                 <div class="naslov">
                                <h3 > Svi zapisi dnevnika </h3>

                            </div>
                                
                                  <p>  
                                     <label  style="width: 20%"id = "Lnaziv" for="naziv">Traži:      
                               </label> <input type="text" ng-model="test"></p>
                                 
                                
                                
                                <table style = "margin-left: 0;width:100%" class="tablica1">
                                     <caption class="tablica1">Pregled dnevnika sustava</caption>
                <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  style="width:400px" custom-sort order="'id'" sort="sort">Vrijeme&nbsp;</th>
                        <th  custom-sort order="'name'" sort="sort">Adresa&nbsp;</th>
                        <th class="description" custom-sort order="'description'" sort="sort">Skripta&nbsp;</th>
                        <th class="field3" custom-sort order="'field3'" sort="sort">Ime&nbsp;</th>
                        <th class="field4" custom-sort order="'field4'" sort="sort">Prezime &nbsp;</th>
                        <th class="field5" custom-sort order="'field5'" sort="sort">Aktivnost&nbsp;</th>
                    </tr>
                </thead>
                <tfoot class="tablica1">
                    <td colspan="6">
                        <div style="width:50%; margin-left:29%; margin-bottom: 5px;margin-top: 5px" >
                            <ul>
                                <li class="preNext" 
                                    
                                    ng-class="{ disabled: currentPage == 0 }" 
                                    
                                    >
                                    <a href ng-click="prevPage()">« Prethodna</a>
                                </li>
                            
                                <li class="preNext" ng-repeat="n in range(pagedItems.length, currentPage, currentPage + gap) "
                                   
                                    ng-class="{ active: n == currentPage }"
                                    
                                    
                                ng-click="setPage()">
                                    <a href ng-bind="n + 1">1</a>
                                </li>
                             
                                <li class="preNext"
                                    
                                    ng-class="{ disabled: (currentPage) == pagedItems.length - 1 }"
                                     >
                                  
                                    <a href ng-click="nextPage()">Sljedeća»</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tfoot>
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in pagedItems[currentPage] | orderBy:sort.sortingOrder:sort.reverse | filter:test">
                        <td style="width:400px">{{item.Vrijeme}}</td>
                        <td>{{item.Adresa}}</td>
                         <td>{{item.Skripta}}</td>
                         <td>{{item.Ime}}</td>
                        <td>{{item.Prezime}}</td> 
                        <td>{{item.Aktivnost}}</td>
                        
                       
                       
                    </tr>
                </tbody>
            </table>
                    
                    
                    
                    
                    
                    
                               



                            </div>
<?php }?>

 <?php if (isset($_smarty_tpl->tpl_vars['korisnik']->value)&&$_smarty_tpl->tpl_vars['korisnik']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3> Pregled po korisniku </h3> 
                            </div>

         <div style="margin-left: 33%"> 

    <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Ime korisnika:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                    <?php if (isset($_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value)&&$_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value) {?>
                                  <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>

 

  <option  value="<?php echo $_smarty_tpl->tpl_vars['elem']->value['korisnik_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['ime'];?>
 <?php echo $_smarty_tpl->tpl_vars['elem']->value['prezime'];?>
 </option>
  
                                  
                                  <?php } ?>     
  <?php }?>
</select>

<br>



                                <input ng-click="prikaziKorisniku()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
    
    
    
    <?php if (isset($_smarty_tpl->tpl_vars['tipZapisa']->value)&&$_smarty_tpl->tpl_vars['tipZapisa']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Pregled po tipu zapisa</h3> 
                            </div>

         <div style="margin-left: 33%"> 

    <label  style="margin-left: -33%"id = "Lnaziv" for="kod">Tip aktivnosti:      
                              </label>

                                
                                
             <select name="aktivnost" ng-model="aktivnost"  style = "height: 30px"  required="">
     
                                    <?php if (isset($_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value)&&$_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value) {?>
                                  <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisSvihAktivnosti']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>

 

  <option  value="<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_aktivnosti'];?>
"><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_aktivnosti'];?>
</option>
  
                                  
                                  <?php } ?>     
  <?php }?>
</select>
<br>




                                <input ng-click="prikaziAktivnosti()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
    
    
    
<?php if (isset($_smarty_tpl->tpl_vars['interval']->value)&&$_smarty_tpl->tpl_vars['interval']->value) {?>
    
     <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  >


                                 <div class="naslov">
                                
 <h3 >Pregled po intervalu</h3> 
                            </div>

         <div style="margin-left: 33%"> 

    <label  style=""id = "Lnaziv" for="kod">OD:      
                              </label>

                                <input ng-model="ODinterval" style="width: 50%;" type="date" id="kod"  placeholder = "gggg-mm-dd" required> <br> 

    <label  style=""id = "Lnaziv" for="kod">DO:      
                              </label>

                                <input ng-model="DOinterval" style="width: 50%;" type="date" id="kod"  placeholder = "gggg-mm-dd" required> <br> 





                                <input ng-click="prikazIntervala()" style="margin-left: -25%"class="gumb" name="provjeraKod" type="submit" value="Pregled"> <br>


         </div>






                            </form>
    
                                
                               
    <?php }?>
 <table ng-show="prikaziPoIntervalu" style = "margin-left: 0;width:100%" class="tablica1">
                                     <caption class="tablica1">Pregled dnevnika sustava</caption>
                <thead class="tablica1">

                    <tr class="tablica1_zaglavlje sh480">
                        <th  style="width:200px" custom-sort order="'id'" sort="sort">Vrijeme&nbsp;</th>
                        <th  custom-sort order="'name'" sort="sort">Adresa&nbsp;</th>
                        <th class="description" custom-sort order="'description'" sort="sort">Skripta&nbsp;</th>
                        <th class="field3" custom-sort order="'field3'" sort="sort">Ime&nbsp;</th>
                        <th class="field4" custom-sort order="'field4'" sort="sort">Prezime &nbsp;</th>
                        <th class="field5" custom-sort order="'field5'" sort="sort">Aktivnost&nbsp;</th>
                    </tr>
                </thead>
                <tfoot class="tablica1">
                    <td colspan="6">
                        <div style="width:50%; margin-left:29%; margin-bottom: 5px;margin-top: 5px" >
                            <ul>
                                <li class="preNext" 
                                    
                                    ng-class="{ disabled: currentPage == 0 }" 
                                    
                                    >
                                    <a href ng-click="prevPage()">« Prethodna</a>
                                </li>
                            
                                <li class="preNext" ng-repeat="n in range(pagedItems.length, currentPage, currentPage + gap) "
                                   
                                    ng-class="{ active: n == currentPage }"
                                    
                                    
                                ng-click="setPage()">
                                    <a href ng-bind="n + 1">1</a>
                                </li>
                             
                                <li class="preNext"
                                    
                                    ng-class="{ disabled: (currentPage) == pagedItems.length - 1 }"
                                     >
                                  
                                    <a href ng-click="nextPage()">Sljedeća»</a>
                                </li>
                            </ul>
                        </div>
                    </td>
                </tfoot>
              
                <tbody class="tablica1">
                    <tr class="tablica1_redak1" ng-repeat="item in pagedItems[currentPage] | orderBy:sort.sortingOrder:sort.reverse">
                        <td style="width:200px">{{item.Vrijeme}}</td>
                        <td>{{item.Adresa}}</td>
                         <td>{{item.Skripta}}</td>
                         <td>{{item.Ime}}</td>
                        <td>{{item.Prezime}}</td> 
                        <td>{{item.Aktivnost}}</td>
                        
                       
                       
                    </tr>
                </tbody>
            </table>
                        </div>


                    </div>





                    <!-- modal diskusije-->
                    <div ng-show="prikaziModal && 0" id="myModalNovaDiskusija" style="display: block"class="modal">

                        <!-- Modal content -->
                        <div class="modal-content">
                            <span ng-click="zatvoriModal()" class="close">&times;</span>



                            <div class="naslov">
                                <h1 >Novi kupon </h1>

                            </div>
   <div ng-show="Diskusija.naziv.$error.email2 || (Diskusija.danKraj.$invalid &&Diskusija.danKraj.$dirty )" class="greskeRegistracija" style=""> 

                 

                    <span ng-show="Diskusija.naziv.$error.email2" > Postojeći  naziv</span>

                    <span ng-show="Diskusija.danKraj.$invalid" > Datum kraja je maji od početnog </span>
                </div>

                            <form style="clear:both"class="formaNovaDiskusija" id="novi_proizvod" method="post" name="Diskusija"  
                                  action="kuponiAdmin.php" enctype="multipart/form-data"  >

                                
                               
                                
                                
                                

                                <label  id = "Lnaziv" for="naziv">Naziv kupona:      
                                  
                                </label>

                                <input   ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv"  required > <br> 
                                <!--
                                <input  ng-model="nazivDiskusije" type="text" id="naziv"  name="naziv" email2 required > <br> 
                                
                                   <span ng-show="Diskusija.naziv.$pending.email2">Provjera postojanja naziva...</span>
-->
                                   
                                   
                           
                                <label  id = "Lopis" for="opis">Opis:
                               </label>  
                                <label style="width: 95%">(za <b>podebljanje</b> teksta koristite: &lt;<b>b</b>&gt; tekst &lt;/<b>b</b>&gt;)</label>
                                <label style="width: 95%">(za novi red koristite: &lt;<b>br</b>&gt;)</label>
                                <textarea ng-model="opis" required class = "opis_area" id= "opis" name="opis" rows="5" cols="100" placeholder="Ovdje unesite opis kupona"></textarea><br>



 

                               

                                <input ng-disabled="Diskusija.naziv.$invalid || Diskusija.danPoc.$invalid || Diskusija.danKraj.$invalid || Diskusija.opis.$invalid" class="gumb" type="submit" name="novoKupon" value="Pohrani kupon">

                                <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">



                            </form>



                            </ul>

                            <div class="naslov" style="background: white">
                                <button ng-click="zatvoriModal()" id="btnZatvori"> Zatvori pregled</button> 

                            </div>








                        </div>

                    </div>
                </div>


            </div>

        </div>
<?php }} ?>
