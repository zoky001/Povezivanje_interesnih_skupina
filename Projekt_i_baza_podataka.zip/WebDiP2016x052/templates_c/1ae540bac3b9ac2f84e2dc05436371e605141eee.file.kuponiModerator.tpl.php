<?php /* Smarty version Smarty-3.1.18, created on 2017-06-01 20:34:52
         compiled from "predlosci/kuponiModerator.tpl" */ ?>
<?php /*%%SmartyHeaderCode:447239806592582cd155581-25642520%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1ae540bac3b9ac2f84e2dc05436371e605141eee' => 
    array (
      0 => 'predlosci/kuponiModerator.tpl',
      1 => 1496342085,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '447239806592582cd155581-25642520',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592582cd1902c5_66392702',
  'variables' => 
  array (
    'otvoriFormuKupona' => 0,
    'IDkupona' => 0,
    'ispisUspjeha' => 0,
    'ispisGreske' => 0,
    'ispisSvihKupona' => 0,
    'elem' => 0,
    'ispisAktivnihKupona' => 0,
    'ukpKupona' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592582cd1902c5_66392702')) {function content_592582cd1902c5_66392702($_smarty_tpl) {?>



        <div ng-app="kuponiModerator" ng-controller="cjelo" class="tijelo  tijeloAdmin">


            <div class="section">

                <div class="naslov">
                    <h1>Odabir kupona</h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">

                        <nav style="width:20%;">

                            <h4>Aktivnosti:</h4>
                            <ul>
                                <li ng-click="PrikaziSve()"> <a>Svi kuponi</a></li>
                                <br>
                                <li ng-click="PrikaziKupljene()"> <a>Aktivni kuponi</a></li>
                                <br>
                                <li ng-click="PrikaziProvjeru()"> <a>Provjera kupona</a></li>
                            </ul>


                        </nav>
                        
                        
                       
                        
                        <?php if (isset($_smarty_tpl->tpl_vars['otvoriFormuKupona']->value)&&$_smarty_tpl->tpl_vars['otvoriFormuKupona']->value) {?>
                            <div class="galerija" >
                            
                                <div class="naslov">
                                    <h1 >Dodavanje novog kupona </h1>

                                </div>

                                <form style="text-align: left" class="formaNovaDiskusija" id="novi_proizvod" method="post" name="novi_proizvod"  
                                      action="kuponiModerator.php">





                                    <input  style="display: none" id="IDkupona"  name="IDkupona" value="<?php echo $_smarty_tpl->tpl_vars['IDkupona']->value;?>
" >


                                    <label  for="kolBodova"> Potreban broj bodova:
                                     
                                    </label>
                                    <input type="number" id="kolBodova"  min = "1" name="kolBodova" required>

                                    <br>

                                    <label   for="danPocetka">Početak:
                                  </label>
                                    <input type="date" id="danPocetka" placeholder = "dd.mm.gggg." name="danPocetka" required>


                                    <br>


                                    <label  for="danKraj">Kraj:
                                   </label>
                                    
                                    <input type="date" id="danKraj" placeholder = "dd.mm.gggg." name="danKraj" required>

                                    <br>





                                    <input class="gumb" name="dodajKupon" type="submit" value="Dodaj kupon"> <br>

                                    <input class= "gumb" style = "color:red" id="reset1" type="reset" value=" Inicijaliziraj">







                                </form>
                        </div>
                                    <?php } elseif (isset($_smarty_tpl->tpl_vars['ispisUspjeha']->value)||isset($_smarty_tpl->tpl_vars['ispisGreske']->value)) {?>
                       
                                     <div class="galerija">
                           <?php if (isset($_smarty_tpl->tpl_vars['ispisUspjeha']->value)&&$_smarty_tpl->tpl_vars['ispisUspjeha']->value) {?> 
                             <div  class="uspjeh" style="display: block;width:50%;margin-left: 25%;"> 
                                 <p>Kod je ispravan!!</p>
                             </div>
                           <?php }?>
                             <?php if (isset($_smarty_tpl->tpl_vars['ispisGreske']->value)&&$_smarty_tpl->tpl_vars['ispisGreske']->value) {?> 
                             <div  class="greske" style="display: block;width:50%;margin-left: 25%;"> 
                                 <p>Uneseni je nepostojeći kod kupona!!</p>
                             </div>
                           <?php }?>
                        
                                         
                                         
                                    <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  action="kuponiModerator.php">


                                 <div class="naslov">
                                
 <h3 >Provjera kupona</h3> 
                            </div>

                                <label  style="width: 17%"id = "Lnaziv" for="kod">Kod:      
                              </label>

                                <input style="width: 70%;" type="text" id="kod"  name="kod" required> <br> 







                                <input style="margin-left: -20%"class="gumb" name="provjeraKod" type="submit" value="Provjeri valjanost"> <br>









                            </form>         
                                         
                        </div>
                                    
                                    <?php } else { ?>




                        


                               








                        
                        <div ng-show="prikaziSve" class="galerija">
                            
                               <div class="naslov">
                                
 <h3 >Svi kuponi</h3> 
                            </div>

                            <div style="text-align: left">
                               
         <?php if (isset($_smarty_tpl->tpl_vars['ispisSvihKupona']->value)&&$_smarty_tpl->tpl_vars['ispisSvihKupona']->value) {?>                       
 <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisSvihKupona']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>                               
                                <div class="kupon">
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['Slika'];?>
"style="max-width: 100%;height: 200px;">
                                    <p><b><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_kupona'];?>
</b></p>

                                    <div class="ikonaKupi">
                                        <a href='kupon.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
'>  <button class="gumbKupnjaKupona"> Pregled </button></a>
                                         <a href='kuponiModerator.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&aktivnost=dodaj'><button class="gumbKupnjaKupona dodajKupon">Dodaj</button></a>

                                    </div>


                                </div>
                                
       <?php } ?>
<?php }?>
                            </div>
                        </div>
                        
                        <div ng-show="prikaziKupljene" class="galerija">
                            
                           
   <div class="naslov">
                                
 <h3 >Aktivni kuponi</h3> 
                            </div>
                           

                            <div style="text-align: left">
                               
                        <?php if (isset($_smarty_tpl->tpl_vars['ispisAktivnihKupona']->value)&&$_smarty_tpl->tpl_vars['ispisAktivnihKupona']->value) {?>                       
 <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisAktivnihKupona']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>                  
                                
                                <div class="kupon">
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['Slika'];?>
"style="max-width: 100%;height: 200px;">
                                    <p><?php echo $_smarty_tpl->tpl_vars['elem']->value['Naziv_kupona'];?>
<br><b><strong>CIJENA: </strong><?php echo $_smarty_tpl->tpl_vars['elem']->value['Min_broj_bodova'];?>
</b></p>

                                    <div class="ikonaKupi">
                                         <button class="gumbKupnjaKupona" onclick="window.location.href='kupon.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_podrucja'];?>
'"> Pregled </button>
                                         <a href="kuponiModerator.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_kupona'];?>
&aktivnost=obrisiKupon">  <button class="gumbKupnjaKupona">Obriši</button></a>

                                    </div>


                                </div>
                                
                       <?php } ?>
                       <?php }?>

                            </div>
 
                        </div>
                        
                        
                        <div ng-show="prikaziProvjeru" class="galerija">
                            




                            <form style="text-align: left"  class="provjraKupona" method="post" name="ProvjeraKoda"  
                                  action="kuponiModerator.php">


                                 <div class="naslov">
                                
 <h3 >Provjera kupona</h3> 
                            </div>

                                <label  style="width: 17%"id = "Lnaziv" for="kod">Kod:      
                              </label>

                                <input style="width: 70%;" type="text" id="kod"  name="kod" required> <br> 







                                <input style="margin-left: 0%"class="gumb" name="provjeraKod" type="submit" value="Provjeri valjanost"> <br>









                            </form>


                        </div>

<?php }?>
                    </div>

                    <div class="desnoOglasi">
                        <p >Trenutno aktivnih kupona:</p>

                        
                            <?php if (isset($_smarty_tpl->tpl_vars['ukpKupona']->value)&&$_smarty_tpl->tpl_vars['ukpKupona']->value) {?>
                          <h1>  <?php echo $_smarty_tpl->tpl_vars['ukpKupona']->value;?>
</h1>
                        <?php } else { ?>
                             <h1> 0 </h1>
                            
                            <?php }?>
                        

                    </div>
                </div>


            </div>

        </div>
<?php }} ?>
