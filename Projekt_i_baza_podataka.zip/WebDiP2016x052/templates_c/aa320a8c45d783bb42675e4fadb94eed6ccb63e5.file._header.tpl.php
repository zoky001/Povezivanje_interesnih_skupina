<?php /* Smarty version Smarty-3.1.18, created on 2016-01-19 11:07:10
         compiled from "predlosci\_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12115569e0ace255db6-66793544%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa320a8c45d783bb42675e4fadb94eed6ccb63e5' => 
    array (
      0 => 'predlosci\\_header.tpl',
      1 => 1453197902,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12115569e0ace255db6-66793544',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'naslov' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_569e0ace27e0d0_70965014',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_569e0ace27e0d0_70965014')) {function content_569e0ace27e0d0_70965014($_smarty_tpl) {?><html>
   <head>
      <title><?php echo $_smarty_tpl->tpl_vars['naslov']->value;?>
</title>
      <meta charset="utf-8"> 
    </head>
   <body>
        <header>
            ZADAĆA 5, 2. DIO
        </header>
        <section id='sadrzaj'> <?php }} ?>
