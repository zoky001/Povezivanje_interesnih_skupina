<?php /* Smarty version Smarty-3.1.18, created on 2017-05-24 19:10:12
         compiled from "predlosci/dizajn.tpl" */ ?>
<?php /*%%SmartyHeaderCode:6479427355925aad32ffdb3-72734636%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5d7e7abba21a35914b2ca0f5602062f7ccd66ea2' => 
    array (
      0 => 'predlosci/dizajn.tpl',
      1 => 1495645792,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6479427355925aad32ffdb3-72734636',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5925aad3339697_25406443',
  'variables' => 
  array (
    'dizajnPromjenaIF' => 0,
    'podrucjeMOD' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5925aad3339697_25406443')) {function content_5925aad3339697_25406443($_smarty_tpl) {?>


        <div class="tijelo  tijeloAdmin">


            <div class="section">

                <div class="naslov">
                    <h1>Odabir dizajna stranica</h1>

                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">









                        <div class="galerijaKupon">
 <?php if (isset($_smarty_tpl->tpl_vars['dizajnPromjenaIF']->value)&&$_smarty_tpl->tpl_vars['dizajnPromjenaIF']->value) {?> 
                             <div  class="uspjeh" style="display: block;width:50%;margin-left: 25%;"> 
                                 <p>Uspješno izmjenjen dizajn područja interesa!!</p>
                             </div>
                           <?php }?>

                            <form style="text-align: left"  class="provjraKupona" method="post" name="OdabirDizajna"  
                                  action="dizajn.php">


                                <div class="naslov">
                                    <h4><?php echo $_smarty_tpl->tpl_vars['podrucjeMOD']->value;?>
</h4>

                                </div>



                                <label  style="width: 50%"id = "Lnaziv" for="bojaBody">Boja pozadine (Body):      
                               </label>



                                <input style="width: 40%;" type="color" name="bojaBody" value="#F5FFDC" required>

                                <br>


                                <label  style="width: 50%"id = "Lnaziv" for="bojaSlova">Boja slova:      
                              </label>



                                <input id ="bojaSlova" style="width: 40%;" type="color" name="bojaSlova" value="#000000" required>

                                <br>
                                
                                
                                   <label  style="width: 50%"id = "Lnaziv" for="bojaSekcije">Boja pozadine sekcije:      
                               </label>



                                <input id ="bojaSekcije" style="width: 40%;" type="color" name="bojaSekcije" value="#EFFFC7" required>

                                <br>
                                
                                      <label  style="width: 50%"id = "Lnaziv" for="bojaObrubaSekcije">Boja obruba sekcije:      
                               </label>



                                <input id ="bojaObrubaSekcije" style="width: 40%;" type="color" name="bojaObrubaSekcije" value="#4E5247" required>

                                <br>



                                <input class="gumb" name="spremiDizajn" type="submit" value="Pohrani dizajn"> <br>









                            </form>


                        </div>


                    </div>
<!--
                    <div class="desnoOglasi">
                        <p >Trenutno aktivnih kupona:</p>

                        <h1>5</h1>

                    </div>-->
                </div>


            </div>

        </div>
  <?php }} ?>
