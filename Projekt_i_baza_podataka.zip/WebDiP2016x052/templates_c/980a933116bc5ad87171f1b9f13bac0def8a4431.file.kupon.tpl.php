<?php /* Smarty version Smarty-3.1.18, created on 2017-06-02 17:51:08
         compiled from "predlosci/kupon.tpl" */ ?>
<?php /*%%SmartyHeaderCode:35955632592422edd23ac6-76134679%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '980a933116bc5ad87171f1b9f13bac0def8a4431' => 
    array (
      0 => 'predlosci/kupon.tpl',
      1 => 1496418652,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '35955632592422edd23ac6-76134679',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_592422edd5c467_71798495',
  'variables' => 
  array (
    'ispisKupona' => 0,
    'kupljen' => 0,
    'galerija' => 0,
    'elem' => 0,
    'brojBodova' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592422edd5c467_71798495')) {function content_592422edd5c467_71798495($_smarty_tpl) {?>



        <div ng-app="kupon" ng-controller="cijelo" class="tijelo">


            <div class="section">
<?php if (isset($_smarty_tpl->tpl_vars['ispisKupona']->value)&&$_smarty_tpl->tpl_vars['ispisKupona']->value) {?>
                <div class="naslov">
                    <h1><?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Naziv_kupona'];?>
  </h1>
               
                </div>


                <div style="width: 100%;">
                    <div class="glavniDio">


                      


                        <div ng-init="izvor = '<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Slika'];?>
 '"   class="galerijaKupon">
<?php if (isset($_smarty_tpl->tpl_vars['kupljen']->value)&&$_smarty_tpl->tpl_vars['kupljen']->value) {?>
    <?php } else { ?>
                            <div >
                                <a href="kosarica.php?IDkupona=<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['ID_kupona'];?>
&IDpodrucja=<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['ID_podrucja'];?>
">  <button class="gumbKupi" style="width: 100%"> U košaricu za - <b><?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Min_broj_bodova'];?>
 </b> bodova</button></a>
                            </div>
<?php }?>
<br>
   <div >
       <a target="_blank" href="pdf/phpCreate.php?Naziv=<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Naziv_kupona'];?>
&Opis=<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Opis_kupona'];?>
&Slika=<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Slika'];?>
">  <button class="gumbKupi" style="width: 100%"> Preuzimi <b>PDF</b> dokument. </button></a>
                            </div>
<br>
                            <div>
                                <img ng-src="{{izvor}}" style="width:100%; max-height: 400px;margin-bottom:-6px">
                              
                            </div>

                            <div style="text-align: left">
                                <div class="kupon">
                                    <img ng-click="PromjeniSliku($event)" ng-model="slika1" src="<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Slika'];?>
"style="max-width: 100%;height: 200px;">



                                </div>
                                
                                <?php if (isset($_smarty_tpl->tpl_vars['galerija']->value)&&$_smarty_tpl->tpl_vars['galerija']->value) {?>
                                  <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['galerija']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>


                                <div class="kupon">
                                    <img ng-click="PromjeniSliku($event)" src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['Slika'];?>
" style="max-width: 100%;height: 200px;">



                                </div>
<?php } ?>
                                <?php }?>
                               




                            </div>
                            <br>
                            <hr style="width: 100%">
                            <br>
                            
                            <?php ob_start();?><?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Video'];?>
<?php $_tmp1=ob_get_clean();?><?php if (isset($_tmp1)&&$_smarty_tpl->tpl_vars['ispisKupona']->value['Video']) {?>
                           
                            
                            <br>

                            
                           <iframe width="420" height="345" 
              src="<?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Video'];?>
" frameborder="0" allowfullscreen >
</iframe>
                            
                            <?php }?>
                            <br>
                            <hr style="width: 100%">
                            <br>


                            <div style="text-align: left">
                                <h3><b>Opis kupona</b></h3>
                                <p><?php echo $_smarty_tpl->tpl_vars['ispisKupona']->value['Opis_kupona'];?>
</p>
                            </div>
                            
                            

                        </div>


                    </div>

                    <div class="desnoOglasi">
                        <p >Ukupan broj bodova:</p>

                        <h1><?php echo $_smarty_tpl->tpl_vars['brojBodova']->value;?>
</h1>

                    </div>
                </div>


            </div>
<?php }?>
        </div>
   <?php }} ?>
