<?php /* Smarty version Smarty-3.1.18, created on 2017-06-03 11:23:32
         compiled from "predlosci/diskusija.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13592034725923eaea28fe83-98816604%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2e9d7ab2b687724c6a769687d7d918579d1b642e' => 
    array (
      0 => 'predlosci/diskusija.tpl',
      1 => 1496481693,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13592034725923eaea28fe83-98816604',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5923eaea2ce867_99377527',
  'variables' => 
  array (
    'Diskusija' => 0,
    'ispisKomentara' => 0,
    'elem' => 0,
    'pravo' => 0,
    'korisnikID' => 0,
    'pravoKomentiranjaIF' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5923eaea2ce867_99377527')) {function content_5923eaea2ce867_99377527($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include '/var/www/webdip.barka.foi.hr/2016_projekti/WebDiP2016x052/vanjske_biblioteke/Smarty/libs/plugins/modifier.date_format.php';
?>


        <div class="tijelo">
            
            
      

            <section id="sadrzaj" class="section1">

            <div class="naslov">
                <h1 ><?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['Naziv'];?>
 </h1>

            </div>



   <div class="temaDiskusije">
        
       <img src="<?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['slika'];?>
" alt="Avatar" class="slikaKomntar" style="width:60px">
       <span class="vrijemekomentara"><strong>Datum otvranja diskusije: </strong><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['Diskusija']->value['Datum_pocetka'],"%d. %m. %Y.");?>
</span>
        <h4> <?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['ime'];?>
 <?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['prezime'];?>
</h4>
        <br>
        <hr>
        <p><?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['Opis_pravila'];?>
</p>
       
        
         
       
        
        <a href="#newKomentar"><button type="button" class=""> Komentiraj </button> </a>
    </div>  
            <?php  $_smarty_tpl->tpl_vars['elem'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['elem']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['ispisKomentara']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['elem']->key => $_smarty_tpl->tpl_vars['elem']->value) {
$_smarty_tpl->tpl_vars['elem']->_loop = true;
?>


<div class="komentar">
        
       <img src="<?php echo $_smarty_tpl->tpl_vars['elem']->value['slika'];?>
" alt="Avatar" class="slikaKomntar" style="width:60px">
        <span class="vrijemekomentara"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['elem']->value['Vrijeme'],"%d. %m. %Y.");?>
</span>
   
        <h4><?php echo $_smarty_tpl->tpl_vars['elem']->value['ime'];?>
 <?php echo $_smarty_tpl->tpl_vars['elem']->value['prezime'];?>
</h4>
        <br>
        <hr>
        <p><?php echo $_smarty_tpl->tpl_vars['elem']->value['Tekst'];?>
</p>
       
        <?php if ($_smarty_tpl->tpl_vars['pravo']->value||$_smarty_tpl->tpl_vars['korisnikID']->value==$_smarty_tpl->tpl_vars['elem']->value['ID_korisnika']) {?>
        <a href="diskusija.php?IDdiskusije=<?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['ID_diskusije'];?>
&obrisi=komentari&ID=<?php echo $_smarty_tpl->tpl_vars['elem']->value['ID_komentara'];?>
"> <button type="button" class="">Obrisi</button> </a>
       
        <?php }?>
        
        <!--
        <button type="button" class=""> Comment</button> 
        -->
    </div>  


<?php } ?>
            
               
            
            <?php if ($_smarty_tpl->tpl_vars['pravoKomentiranjaIF']->value) {?>
             <div class="noviKomentar">
                 
                 
                 <form  id="newKomentar"  method="post" name="noviKomentar"  
               action="diskusija.php?IDdiskusije=<?php echo $_smarty_tpl->tpl_vars['Diskusija']->value['ID_diskusije'];?>
">
                     <textarea style="width:100%"name="komentar" rows="4"  placeholder="Upišite komentar" required></textarea><br>
                     <input style="width:100%"class="btn" type="submit" name="submit" value="Komentiraj">
                 </form>
              
              
            </div>

<?php }?>
        </section>

  </div>
     
<?php }} ?>
